package com.example.hs.smartfishbowl;

public class PersonalData {
   // private String member_id;
    private String member_temp;
    private String member_turb;

    //public String getMember_id() {
   //     return member_id;
    //}

    public String getMember_temp() {
        return member_temp;
    }

    public String getMember_turb() {
        return member_turb;
    }

   // public void setMember_id(String member_id) {
    //    this.member_id = member_id;
    //}

    public void setMember_temp(String member_temp) {
        this.member_temp = member_temp;
    }

    public void setMember_turb(String member_turb) {this.member_turb = member_turb; }
}
