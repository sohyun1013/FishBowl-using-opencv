package com.example.hs.smartfishbowl;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.mikephil.charting.data.Entry;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class TotalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total);
        setTitle("통합 모니터링");

        TextView tempA = (TextView)findViewById(R.id.tempA);
        TextView turbA = (TextView)findViewById(R.id.turbA);

        ImageView tempImg = (ImageView)findViewById(R.id.tempImg);
        ImageView turbImg = (ImageView)findViewById(R.id.turbImg);

        Intent intent = getIntent();
        ArrayList<Entry> tempList = intent.getParcelableArrayListExtra("tempList");
        Intent intent2 = getIntent();
        ArrayList<Entry> turbList = intent2.getParcelableArrayListExtra("turbList");

        Log.d("value", String.valueOf(tempList.get(1)));
        float value = tempList.get(1).getY();
        if(value>=230){
            Log.d("value","HOT");
            tempA.setText("현재 수온 높음");
            tempImg.setImageResource(R.drawable.thermometerr);
        } else if (value>=200){
            Log.d("value","SOSO");
            tempA.setText("현재 수온 조금 높음");
            tempImg.setImageResource(R.drawable.thermometery);
        } else {
            Log.d("value","COOL");
            tempA.setText("현재 수온 적정");
            tempImg.setImageResource(R.drawable.thermometerg);
        }

        Log.d("tvalue", String.valueOf(turbList.get(1)));
        float value2 = turbList.get(1).getY();
        if(value2>=300){
            Log.d("value","COOL");
            turbA.setText("현재 수질 좋음");
            turbImg.setImageResource(R.drawable.waterdropg);
        } else if (value2>=150){
            Log.d("value","SOSO");
            turbA.setText("현재 수질 조금 나쁨");
            turbImg.setImageResource(R.drawable.waterdropy);
        } else {
            Log.d("value","HOT");
            turbA.setText("현재 수질 나쁨");
            turbImg.setImageResource(R.drawable.waterdropr);
        }

        WebView webView = (WebView)findViewById(R.id.webView);
        webView.setPadding(0,0,0,0);

        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);

        String url = "http://192.168.35.164:8080/javascript_simple.html";
        webView.loadUrl(url);
    }

    public void onClick(View view){         //Activity 전환
        Intent intent = null;
        //GetData task = new GetData();
        //task.execute( "http://" + IP_ADDRESS + "/sensor_db.php", "");
        switch (view.getId()){
            case R.id.button1:
                intent = new Intent(getApplicationContext(), DssActivity.class);
                break;
            case R.id.button2:
                intent = new Intent(getApplicationContext(), PlayActivity.class);
                break;
            case R.id.button3:
                intent = new Intent(getApplicationContext(), TempActivity.class);
                break;
            case R.id.button4:
                intent = new Intent(getApplicationContext(), TurbActivity.class);
                break;
        }
        if(intent != null){
            startActivity(intent);
        }
    }
}
