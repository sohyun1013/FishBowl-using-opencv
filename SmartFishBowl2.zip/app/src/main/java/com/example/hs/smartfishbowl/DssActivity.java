package com.example.hs.smartfishbowl;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.ScatterData;
import com.github.mikephil.charting.data.ScatterDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.IScatterDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class DssActivity extends AppCompatActivity {
    private ScatterChart chart;
    private SeekBar seekBarX, seekBarY;
    private TextView tvX, tvY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dss);

        setTitle("이상 증세 조회");
        TextView dssA = (TextView)findViewById(R.id.dssA);
        ImageView dssImg = (ImageView)findViewById(R.id.dssImg);

        ArrayList<Entry> values1 = new ArrayList<>();

        values1.add(new Entry(5, 50));
        values1.add(new Entry(10, 56));
        values1.add(new Entry(14, 53));
        values1.add(new Entry(17, 54));
        values1.add(new Entry(18, 59));
        values1.add(new Entry(23, 57));
        values1.add(new Entry(27, 51));
        values1.add(new Entry(33, 53));
        values1.add(new Entry(35, 55));
        values1.add(new Entry(36, 52));
        values1.add(new Entry(43, 58));
        values1.add(new Entry(44, 53));
        values1.add(new Entry(46, 55));
        values1.add(new Entry(48, 50));
        values1.add(new Entry(53, 49));
        values1.add(new Entry(58, 48));
        values1.add(new Entry(59, 51));
        values1.add(new Entry(67, 56));
        values1.add(new Entry(69, 15));
        values1.add(new Entry(73, 10));
        values1.add(new Entry(77, 32));
        values1.add(new Entry(79, 36));
        values1.add(new Entry(82, 19));
        values1.add(new Entry(85, 22));
        values1.add(new Entry(89, 6));
        values1.add(new Entry(90, 11));
        values1.add(new Entry(95, 42));
        values1.add(new Entry(98, 18));
        values1.add(new Entry(100, 15));
        values1.add(new Entry(102, 3));
        values1.add(new Entry(35, 57));
        values1.add(new Entry(22, 51));

        ScatterDataSet set1 = new ScatterDataSet(values1, "pos");
        set1.setScatterShape(ScatterChart.ScatterShape.CIRCLE);
        set1.setColor(ColorTemplate.COLORFUL_COLORS[0]);

        set1.setScatterShapeSize(30f);
        ArrayList<IScatterDataSet> dataSets = new ArrayList<>();
        dataSets.add(set1); // add the data sets

        chart = findViewById(R.id.chart);
        chart.getDescription().setEnabled(false);

        chart.setDrawGridBackground(true);
        chart.setTouchEnabled(true);
        chart.setMaxHighlightDistance(100f);

        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);

        chart.setMaxVisibleValueCount(100);
        chart.setPinchZoom(true);

        Legend l = chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        //l.setTypeface(tfLight);
        l.setXOffset(5f);

        YAxis yl = chart.getAxisLeft();
        //yl.setTypeface(tfLight);
        yl.setAxisMinimum(0f); // this replaces setStartAtZero(true)

        chart.getAxisRight().setEnabled(false);

        XAxis xl = chart.getXAxis();
        //xl.setTypeface(tfLight);
        xl.setDrawGridLines(false);

        ScatterData data = new ScatterData(dataSets);
        chart.setData(data);
        chart.invalidate();

        Log.d("tvalue", String.valueOf(values1.get(1)));
        float value2 = values1.get(1).getY();
        int num=0;
        //int num2=0;
        for(int i=0; i<30;i++){
            if(values1.get(i).getY()>=50){
                num+=1;
                Log.d("movemove","move");
            }
        }
        if(num>=20){
            Log.d("value","COOL");
            dssA.setText("이상 움직임 감지(상단)");
            dssImg.setImageResource(R.drawable.alarmr);
        } else {
            Log.d("value","SOSO");
            dssA.setText("움직임 이상 없음");
            dssImg.setImageResource(R.drawable.alarmg);
        }
    }
}