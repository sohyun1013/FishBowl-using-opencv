package com.example.hs.smartfishbowl;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.github.mikephil.charting.data.Entry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Navigation extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private static String IP_ADDRESS = "192.168.35.164";
    private static String TAG = "phptest";
    private String mJsonString;

    ArrayList<Entry> tempList = new ArrayList<>();
    ArrayList<Entry> xyList = new ArrayList<>();
    ArrayList<Entry> turbList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("SMART FISH BOWL");

        GetData task = new GetData();
        task.execute( "http://" + IP_ADDRESS + "/sensor_db.php", "");

        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation, menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        Intent intent = null;
        switch(item.getItemId()){
            case R.id.total:
                intent = new Intent(getApplicationContext(), TotalActivity.class);
                break;
        }
        if(intent != null){
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Intent intent = null;
        if (id == R.id.nav_camera) {
            // Handle the camera action
            intent = new Intent(getApplicationContext(), DssActivity.class);
        } else if (id == R.id.nav_gallery) {
            intent = new Intent(getApplicationContext(), PlayActivity.class);
        } else if (id == R.id.nav_slideshow) {
            intent = new Intent(getApplicationContext(), TempActivity.class);
        } else if (id == R.id.nav_manage) {
            intent = new Intent(getApplicationContext(), TurbActivity.class);
        } else if (id == R.id.nav_dictionary) {
            intent = new Intent(getApplicationContext(), DictionaryActivity.class);
        } else if (id == R.id.nav_send) {

        }
        if(intent != null){
            startActivity(intent);
            intent = null;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void onClick(View view){         //Activity 전환
        Intent intent = null;
        //GetData task = new GetData();
        //task.execute( "http://" + IP_ADDRESS + "/sensor_db.php", "");
        switch (view.getId()){
            case R.id.button1:
                intent = new Intent(getApplicationContext(), DssActivity.class);
                break;
            case R.id.button2:
                intent = new Intent(getApplicationContext(), TotalActivity.class);
                intent.putExtra("tempList",tempList);
                intent.putExtra("turbList",turbList);
                break;
            case R.id.button3:
                intent = new Intent(getApplicationContext(), TempActivity.class);
                intent.putExtra("tempList",tempList);
                break;
            case R.id.button4:
                intent = new Intent(getApplicationContext(), TurbActivity.class);
                intent.putExtra("turbList",turbList);
                break;
        }
        if(intent != null){
            startActivity(intent);
        }
    }

    private class GetData extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(Navigation.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            //mTextViewResult.setText(result);
            Log.d(TAG, "response - " + result);

            if (result == null){
                //mTextViewResult.setText(errorString);
            }
            else {
                mJsonString = result;
                showResult();
            }
        }

        @Override
        protected String doInBackground(String... params) {
            String serverURL = params[0];
            String postParameters = params[1];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();

                return sb.toString().trim();
            } catch (Exception e) {
                Log.d(TAG, "GetData : Error ", e);
                errorString = e.toString();

                return null;
            }
        }
    }


    private void showResult(){
        String TAG_JSON="result";
        //String TAG_ID = "result";
        String TAG_TEMP = "temp";
        String TAG_TURB ="tubi";
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                //String id = item.getString(TAG_ID);
                String temp = item.getString(TAG_TEMP);
                String turb = item.getString(TAG_TURB);

                PersonalData personalData = new PersonalData();

                //personalData.setMember_id(id);
                personalData.setMember_temp(temp);
                personalData.setMember_turb(turb);

                float temp2 = Float.parseFloat(temp.toString());
                float turb2 = Float.parseFloat(turb.toString());

                int temp3 = (int)(temp2*10);
                int turb3 = (int)(turb2*100);

                xyList.add(new Entry(i, temp3));
                tempList.add(new Entry(i, temp3));
                turbList.add(new Entry(i, turb3));
                Log.d("test",temp);
                Log.d("test",turb);
                Log.d("ivalue",String.valueOf(i));
                //mArrayList.add(personalData);
                //mAdapter.notifyDataSetChanged();
            }
        } catch (JSONException e) {
            Log.d(TAG, "showResult : ", e);
        }

    }
}
